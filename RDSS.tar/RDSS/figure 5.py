import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
import matplotlib.cm as cm

# 设置全局字体为 Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.family'] = 'Times New Roman'

# 读取Excel文件（替换为你的文件路径）
file_path = r"D:\project\excel\output_std_deviation45-55.xlsx"  # 这里填写你的文件路径
df = pd.read_excel(file_path)

# 设置月份
months = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]

plt.figure(figsize=(12, 8))

# 获取纬度的最小值和最大值
lat_min = df['Latitude'].min()
lat_max = df['Latitude'].max()

# 定义从黑到浅灰的colormap
colormap = mpl.colors.LinearSegmentedColormap.from_list("black_gray", ["black", "lightgray"])

# 为每个站点绘制折线图
for index, row in df.iterrows():
    station_id = row['station_id']
    latitude = row['Latitude']
    y = row[months].values  # 各个月的值
    x = np.arange(len(y))   # 对应月份的索引

    # 检查y中是否存在NaN值
    if np.isnan(y).any():
        continue  # 如果存在NaN值，则跳过当前迭代

    # 根据纬度选择颜色，低纬度为浅灰，高纬度为黑色
    norm_latitude = (latitude - lat_min) / (lat_max - lat_min)  # 纬度归一化
    color = colormap(norm_latitude)  # 根据归一化后的值选择颜色

    # 绘制折线图（无插值，直接绘制原始数据）
    plt.plot(x, y, label=station_id, color=color, marker='o')

# 设置y轴和x轴的限制范围
plt.ylim(0, 210)
plt.xlim(0, len(months) - 1)

# 设置x轴的刻度标签
plt.xticks(np.arange(len(months)), months, fontsize=26)
plt.yticks(fontsize=26)

# 添加x轴和y轴的标签
#plt.xlabel('', fontsize=16)
#plt.ylabel('Spe', fontsize=16)
plt.savefig(r'C:\Users\PC\Desktop\方差45-55.svg', bbox_inches='tight')

# 显示图表
plt.show()