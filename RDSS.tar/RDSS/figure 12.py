import os
import numpy as np
import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
from datetime import datetime, timedelta
from geopy.distance import geodesic
import cartopy.mpl.ticker as cticker
import matplotlib as mpl
import matplotlib.pyplot as plt
import cartopy.feature as cfeature
plt.rcParams['font.family'] = 'Times New Roman'
# 设置全局字体为 Times New Roman，大小为 14
mpl.rcParams['font.family'] = 'Times New Roman'


# 创建绘图
fig, ax = plt.subplots(figsize=(12, 8), subplot_kw={'projection': ccrs.PlateCarree()})

# 添加高分辨率的海岸线
coastline = cfeature.NaturalEarthFeature('physical', 'coastline', '10m', edgecolor='black', facecolor='none')
ax.add_feature(coastline, linewidth=0.5)

def haversine_distance(lat1, lon1, lat2, lon2):
    radius = 6371  # Earth radius in kilometers
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
    return radius * c
# 创建绘图


start_folder_path = r"D:\2022101312"

end_folder_path = r"D:\city"
#end_folder_path = r"D:\test"

start_points = []
end_points = []
start_times = []

# 提取起始点
for root, dirs, files in os.walk(start_folder_path):
    for file in files:
        if file.endswith('.txt'):
            with open(os.path.join(root, file), 'r', encoding='utf-8') as f:
                lines = f.readlines()
                try:
                    start_lon = float(lines[4].split('Longtitude:')[-1].strip())
                    start_lat = float(lines[5].split('Latitude:')[-1].strip())
                    start_points.append((start_lat, start_lon))
                    print(f"起始点的坐标: {start_lat}")
                except Exception as e:
                    print(f"Error processing file {file}: {e}")

# 提取最后一个点
for root, dirs, files in os.walk(end_folder_path):
    for file in files:
        if file.endswith('.txt'):
            try:
                with open(os.path.join(root, file), 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    end_lon = float(lines[-1].split()[1])
                    end_lat = float(lines[-1].split()[2])
                    end_points.append((end_lat, end_lon))
                    release_time_str = lines[6].split('Release time:')[-1].strip()  # 提取日期时间部分
                    start_time = datetime.strptime(release_time_str, '%Y%m%d%H%M')
                    # 调整时间为加上5.75小时
                    start_time += timedelta(hours=5.75)
                    start_times.append(start_time)
                    print(f"开始时间: {start_time}")
            except Exception as e:
                print(f"Could not process file {file}: {e}")
                continue

dt = xr.open_dataset(r'D:\IBTrACS.WP.v04r00.nc')
TC_lat = dt['usa_lat']
TC_lon = dt['usa_lon']
TC_time_step = dt['iso_time']
TC_year = dt['season']
TC_mask = (TC_year == 2022) | (TC_year == 2023)


latselect = TC_lat.where(TC_mask, drop=True)
lonselect = TC_lon.where(TC_mask, drop=True)
timeselect = TC_time_step.where(TC_mask, drop=True)
# 存储结果
results = []

for lat, lon in zip(latselect, lonselect):
    ax.plot(lon, lat, color='blue', transform=ccrs.Geodetic())
    ax.scatter(lon, lat, color='blue', transform=ccrs.PlateCarree(), marker='o', s=5)
df_typhoon = pd.read_excel(r"D:\project\excel\Typhoon_Tracks_2022_2023.xlsx")

count_marked_points = 0

# 筛选并标记符合条件的路径点
for idx, row in df_typhoon.iterrows():
    lat1 = row['Latitude']
    lon1 = row['Longitude']
    time = row['Time']
    print(f"台风时间: {time}")

    for start_point, end_point in zip(start_points, end_points):
        if (haversine_distance(lat1, lon1, start_point[0], start_point[1]) < 300 or
                haversine_distance(lat1, lon1, end_point[0], end_point[1]) < 300):

            # 假设 start_times 已经包含所有起始时间
            for start_time in start_times:
                time_window_start = start_time - timedelta(hours=2)
                time_window_end = start_time + timedelta(hours=2)
                print(f"时间窗起始：{time_window_start}, 结束：{time_window_end}")

                if time_window_start <= time <= time_window_end:
                    print(f"符合条件的台风点：经度 {lon1}, 纬度 {lat1}, 时间 {time}")
                    ax.scatter(lon1, lat1, color='red', s=10, label='Marked Point', transform=ccrs.Geodetic(), zorder=5)
                    count_marked_points += 1  # 更新计数器

# 循环结束后输出符合条件的点的数量
print(f"总共有 {count_marked_points} 个符合条件的台风点被标记。")

# 绘制起始点和终点
for start_point in start_points:
    ax.scatter(start_point[1], start_point[0], color='black', s=3, label='Start Point', transform=ccrs.Geodetic())

for end_point in end_points:
    ax.scatter(end_point[1], end_point[0],  s=1, label='End Point', transform=ccrs.Geodetic())

plt.legend(fontsize=14)
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))
ax.legend(by_label.values(), by_label.keys())
ax.set_extent([90, 160, 0, 51], crs=ccrs.PlateCarree())
ax.set_xticks(range(90, 161, 10))
ax.set_yticks(range(0, 51, 10))
lon_formatter = cticker.LongitudeFormatter()
lat_formatter = cticker.LatitudeFormatter()
ax.xaxis.set_major_formatter(lon_formatter)
ax.yaxis.set_major_formatter(lat_formatter)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)  # 设置x轴的标签为月份

#plt.xlabel('Lon', fontsize=14)
#plt.ylabel('Lat', fontsize=14)
#ax.set_xlabel('Longitude [°]', fontsize=14)
#ax.set_ylabel('Latitude [°]', fontsize=14)

#plt.title('Typhoon Paths', fontsize=14)
#plt.savefig(r'C:\Users\PC\Desktop\台风路径.tif',  dpi=500)
plt.savefig(r"C:\Users\PC\Desktop\台风路径12.10.svg", format='svg',bbox_inches='tight')
plt.show()