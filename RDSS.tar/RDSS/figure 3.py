import os
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import matplotlib
import matplotlib.pyplot as plt
from cartopy.io.shapereader import Reader
from matplotlib.patches import Patch
import frykit.plot as fplt
from cartopy.io.shapereader import Reader
from cartopy.mpl.patch import geos_to_path
import geopandas as gpd
import matplotlib as mpl
import matplotlib.pyplot as plt

# 设置全局字体为 Times New Roman，大小为 14
mpl.rcParams['font.family'] = 'Times New Roman'
#mpl.rcParams['font.size'] = 16
#matplotlib.use('TkAgg')  # 使用Tkinter作为后端
folder_path = r"C:\Users\PC\Desktop\BEIJING"  # 文件夹路径
#file_path = r"C:\Users\PC\Desktop\SHANTOU\Sonde_Traj_SHANTOU_59316_202202010015.txt"
# 创建交互式地图
#fig, ax = plt.subplots(1, 1, subplot_kw={'projection': ccrs.PlateCarree()}, figsize=(12, 8))

# Initialize the map
crs = ccrs.PlateCarree()
fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(projection=crs)

# Add features to the map
fplt.add_cn_border(ax)
fplt.add_nine_line(ax)
fplt.add_cn_province(ax)
# 添加全国边界底图
#boundary_path = cfeature.NaturalEarthFeature(category='cultural', name='admin_0_boundary_lines_land', scale='10m',
                                             #facecolor='none', edgecolor='gray')
#ax.add_feature(boundary_path, linestyle='-', linewidth=1.0, edgecolor='black')

# 添加京津冀边界底图
#boundary_path = cfeature.NaturalEarthFeature(category='cultural', name='admin_1_states_provinces_lines', scale='10m', facecolor='none', edgecolor='gray')
#ax.add_feature(boundary_path, linestyle='-', linewidth=1.0, edgecolor='black')
# 颜色映射
color_mapping = {
    "01": "indigo",
    "02": "purple",
    "03": "magenta",
    "04": "pink",
    "05": "yellow",
    "06": "gold",
    "07": "darkgoldenrod",
    "08": "red",
    "09": "lime",
    "10": "lightblue",
    "11": "royalblue",
    "12": "blue",
}
# 遍历文件夹中的文件
for file_name in os.listdir(folder_path):
    # 构建完整文件路径
    file_path = os.path.join(folder_path, file_name)

    # 读取文件数据并提取信息
    with open(file_path, "r") as file:
        data = file.readlines()

        # 提取最后一个点的经纬度
        if len(data) > 11:
            last_line = data[-1].split()
            if len(last_line) >= 4:
                try:
                    last_lon = float(last_line[1])
                    last_lat = float(last_line[2])
                except (ValueError, IndexError):
                    continue

        # 提取Release time中的第五位和第六位数字
        release_time = data[6].split()[-1]
        if len(release_time) >= 2:
            color_code = release_time[4:6]

            if color_code in color_mapping:
                color = color_mapping[color_code]

                ax.scatter(last_lon, last_lat, color=color, s=10, transform=ccrs.PlateCarree())


#legend_elements = [Patch(facecolor=color, label=f"{code}") for code, color in color_mapping.items()]
#ax.legend(handles=legend_elements)



if file_path.endswith(".txt"):
    with open(file_path, "r") as file:
        data = file.readlines()
    first_line = data[10].split()
    lon_given = float(first_line[1])
    lat_given = float(first_line[2])

# Add release point with black marker, and label it 'release point'
#ax.scatter(lon_given, lat_given, color='black', marker='o', s=15, transform=ccrs.PlateCarree(), label='release point')

ax.set_extent([115, 145, 35, 55], crs=ccrs.PlateCarree())

#ax.set_title('HAIKOU Trajectory Forecast',fontsize=20)

gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True, linewidth=1, color='gray', alpha=0.5, linestyle='--')
gl.top_labels = False
gl.right_labels = False

release_time = ax.scatter(lon_given, lat_given, color='black', marker='^', s=150, transform=ccrs.PlateCarree(), label='station')
legend_elements = [Patch(facecolor=color, label=f"{code}") for code, color in color_mapping.items()]
legend_elements.append(release_time)
# 设置 x 和 y 轴刻度字体大小为 16
gl.xlabel_style = {'size': 26}
gl.ylabel_style = {'size': 26}

ax.legend(handles=legend_elements, loc='upper right', fontsize=16)
#plt.savefig(r"C:\Users\PC\Desktop\哈尔滨.svg", format='svg', dpi=5, bbox_inches='tight')
plt.show()
