import os
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.patches import Patch
import matplotlib
matplotlib.use('TkAgg')  # 使用Tkinter作为后端
import cartopy.mpl.ticker as cticker
import frykit.plot as fplt
import matplotlib.font_manager as fm
from matplotlib.lines import Line2D
# 设置全局字体为 Times New Roman，大小为 14
plt.rcParams['font.family'] = 'Times New Roman'
folder_path = r"E:\Traj_Data"
#folder_path = r"D:\test"
# 第一个点的经纬度提取路径
first_point_path = r"E:\Traj_Data\2022020100"

# 最后一个点的经纬度提取路径
last_point_path = r"E:\Traj_Data"
#last_point_path = r"D:\test"

# 创建交互式地图
fig, ax = plt.subplots(subplot_kw={'projection': ccrs.PlateCarree()}, figsize=(12, 8))
# 设置显示区域
ax.set_extent([70, 140, 15, 50], crs=ccrs.PlateCarree())

color_mapping = {
    "01": "indigo", "02": "purple", "03": "magenta",
    "04": "pink", "05": "yellow", "06": "gold",
    "07": "darkgoldenrod", "08": "red", "09": "lime",
    "10": "lightblue", "11": "royalblue", "12": "blue"
}

# 添加中国边界和省份
fplt.add_cn_border(ax)
fplt.add_cn_province(ax)

# 遍历每个文件夹，提取最后一个点的经纬度
for root, dirs, files in os.walk(last_point_path):
    for file_name in files:
        if file_name.endswith(".txt"):
            file_path = os.path.join(root, file_name)
            with open(file_path, "r") as file:
                data = file.readlines()
            # 提取最后一个点的经纬度
            if len(data) > 11:
                last_line = data[-1].split()
                if len(last_line) >= 4:
                    try:
                        last_lon = float(last_line[1])
                        last_lat = float(last_line[2])
                        release_time = data[6].split()[-1]
                        color_code = release_time[4:6]
                        if color_code in color_mapping:
                            color = color_mapping[color_code]
                            ax.scatter(last_lon, last_lat, color=color, s=2, transform=ccrs.PlateCarree())
                    except (ValueError, IndexError):
                        continue

# 遍历第一个文件夹里的所有txt文件，提取第一个点的经纬度
for file_name in os.listdir(first_point_path):
    if file_name.endswith(".txt"):
        file_path = os.path.join(first_point_path, file_name)
        with open(file_path, "r") as file:
            data = file.readlines()
        first_line = data[10].split()
        lon_given = float(first_line[1])
        lat_given = float(first_line[2])
        # 提取第一个点的经纬度
        if lon_given is not None and lat_given is not None:
            ax.scatter(lon_given, lat_given, color='black', marker='^', s=15,
                       transform=ccrs.PlateCarree(), label='station')

# 创建图例元素
#legend_elements = [Patch(facecolor=color, label=f"{code}") for code, color in color_mapping.items()]
#legend_elements.append(ax.scatter(lon_given, lat_given, color='black', marker='o', s=15, transform=ccrs.PlateCarree(), label='release point'))
# 在循环之外的图例中，手动添加 release point 条目
legend_elements = [Patch(facecolor=color, label=f"{code}") for code, color in color_mapping.items()]

# 使用 Line2D 定义黑色圆点的图例标记
release_point_legend = Line2D([0], [0], marker='^', color='w', markerfacecolor='black', markersize=8, label='station')

# 将 release point 的 Line2D 对象添加到 legend_elements 中
legend_elements.append(release_point_legend)

# 调整图例大小并放置在左下角
ax.legend(handles=legend_elements, loc='lower left', fontsize=10)
# 设置刻度和标签格式
ax.set_xticks(range(70, 141, 10))
ax.set_yticks(range(15, 51, 5))
lon_formatter = cticker.LongitudeFormatter()
lat_formatter = cticker.LatitudeFormatter()
ax.xaxis.set_major_formatter(lon_formatter)
ax.yaxis.set_major_formatter(lat_formatter)

# 设置字体大小和标题
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
#plt.xlabel('Lon', fontsize=14)
#plt.ylabel('Lat', fontsize=14)
#plt.title('Trajectory Forecast', fontsize=14)
#legend_elements = [Patch(facecolor=color, label=f"{code}") for code, color in color_mapping.items()]


# 显式为 release point 添加一个 Patch 条目
#legend_elements.append(Patch(facecolor='black', marker='o',label='release point'))

# 调整图例大小并放置在左下角
#ax.legend(handles=legend_elements, loc='lower left', fontsize=10)

# 添加南海小地图
def get_mini_ax_position(ax, geo_extent, shrink):
    """计算小地图的位置和大小"""
    transformer = ax.transData
    ll = transformer.transform([geo_extent[0], geo_extent[2]])
    ur = transformer.transform([geo_extent[1], geo_extent[3]])

    fig = ax.figure
    ll = fig.transFigure.inverted().transform(ll)
    ur = fig.transFigure.inverted().transform(ur)

    width = ur[0] - ll[0]
    height = ur[1] - ll[1]
    return [ll[0], ll[1], width * shrink, height * shrink]

def add_mini_axes(ax, extent, geo_extent, shrink=0.4, projection=None):
    """添加小地图"""
    if projection is None:
        projection = ccrs.PlateCarree()

    position = get_mini_ax_position(ax, geo_extent, shrink)

    mini_ax = ax.figure.add_axes(position, projection=projection)
    mini_ax.set_extent(extent, crs=projection)
    #mini_ax.background_patch.set_alpha(0)  # 设置背景透明
    #mini_ax.background_patch.set_edgecolor('none')  # 隐藏边框

    # 添加边界和省份
    fplt.add_cn_border(mini_ax)
    fplt.add_nine_line(mini_ax)
    fplt.add_cn_province(mini_ax)

    return mini_ax

mini_ax = add_mini_axes(ax, extent=[105, 125, 0, 25], geo_extent=[132, 142, 15.075, 35.075], shrink=0.8)
ax.set_facecolor("none")  # 设置背景透明

#plt.savefig(r"C:\Users\PC\Desktop\落点和站点分布9.9.svg", format='svg',dpi=5, bbox_inches='tight')
plt.savefig(r"C:\Users\PC\Desktop\落点和站点分布10.14.png", dpi=500, bbox_inches='tight')
plt.show()
