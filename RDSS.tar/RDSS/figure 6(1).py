#uv计算风速
import pandas as pd
import os
import numpy as np

def extract_last_point_coordinates(file_path):
    try:
        with open(file_path, "r", encoding='utf-8') as file:
            data = file.readlines()

            station_id_line = data[2].split(":")
            if len(station_id_line) < 2:
                return None
            station_id = station_id_line[-1].strip()
            if not station_id:
                return None

            lon = float(data[4].split(":")[-1].strip())
            lat = float(data[5].split(":")[-1].strip())

            #if not (70 <= lon <= 140 and 35 <= lat <= 45):
                #return None

            release_month = data[6].split(":")[-1].strip()[4:6]

            # 初始化变量
            w_prev = float('inf')  # 假设初始的w_prev非常大
            critical_u = None
            critical_v = None

            # 提取经纬度和w值数据，找到w值从大于或等于-10变为小于-10的点
            for line in data[11:]:
                values = line.split()
                if len(values) >= 7:
                    try:
                        u_value = float(values[4])
                        v_value = float(values[5])
                        w_value = float(values[6])

                        # 检测w_value从大于等于-10到小于-10的变化
                        if w_value < -10 and w_prev >= -10:
                            critical_u = u_value
                            critical_v = v_value

                        w_prev = w_value  # 更新前一个w值

                    except (ValueError, IndexError):
                        continue

            # 如果找到了关键的u和v值，计算风速
            if critical_u is not None and critical_v is not None:
                wind_speed = np.sqrt(critical_u ** 2 + critical_v ** 2)
                return station_id, release_month, wind_speed

    except Exception as e:
        return None

    # 如果没有找到满足条件的u和v，返回None
    return None


def process_files_in_folder(folder_path):
    station_data = {}
    rows_list = []

    for root, _, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith(".txt"):
                file_path = os.path.join(root, file_name)
                result = extract_last_point_coordinates(file_path)
                if result:
                    station_id, month, wind_speed = result
                    if station_id not in station_data:
                        station_data[station_id] = {}
                    station_data[station_id].setdefault(month, []).append(wind_speed)

    final_results = pd.DataFrame(index=sorted(station_data.keys()))

    for month in range(1, 13):
        month_str = f"{month:02d}"
        for station_id in station_data:
            month_data = station_data[station_id].get(month_str, [])
            final_results.loc[station_id, month_str] = np.nanmean(month_data) if month_data else np.nan

    return final_results


folder_path = "E:\\Traj_Data"
final_df = process_files_in_folder(folder_path)
final_df.to_excel("uv_speed.xlsx", index=True)
