#uv计算风向
import pandas as pd
import os
import numpy as np

def calculate_direction(u, v):
    angle_rad = np.arctan2(u, v)
    angle_deg = (np.degrees(angle_rad) + 360) % 360
    return angle_deg

def extract_last_point_coordinates(file_path):
    try:
        with open(file_path, "r", encoding='utf-8') as file:
            data = file.readlines()
            station_id_line = data[2].split(":")
            if len(station_id_line) < 2:
                return None
            station_id = station_id_line[-1].strip()
            if not station_id:
                return None
            lon = float(data[4].split(":")[-1].strip())
            lat = float(data[5].split(":")[-1].strip())
            release_month = data[6].split(":")[-1].strip()[4:6]
            w_prev = float('inf')
            for line in data[11:]:
                values = line.split()
                if len(values) >= 7:
                    try:
                        u_value = float(values[4])
                        v_value = float(values[5])
                        w_value = float(values[6])
                        if w_value < -10 and w_prev >= -10:
                            return station_id, release_month, calculate_direction(u_value, v_value)
                        w_prev = w_value
                    except (ValueError, IndexError):
                        continue
    except Exception as e:
        print(f"Error processing file {file_path}: {e}")
    return None

def process_files_in_folder(folder_path):
    station_data = {}
    for root, _, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith(".txt"):
                file_path = os.path.join(root, file_name)
                result = extract_last_point_coordinates(file_path)
                if result:
                    station_id, month, direction = result
                    if station_id not in station_data:
                        station_data[station_id] = {}
                    station_data[station_id].setdefault(month, []).append(direction)
    final_results = pd.DataFrame(index=sorted(station_data.keys()))
    for month in range(1, 13):
        month_str = f"{month:02d}"
        for station_id in station_data:
            month_data = station_data[station_id].get(month_str, [])
            if month_data:
                final_results.loc[station_id, month_str] = np.nanmean(month_data)
            else:
                final_results.loc[station_id, month_str] = np.nan
    return final_results

folder_path =  "E:\\Traj_Data"
final_df = process_files_in_folder(folder_path)
final_df.to_excel("WindDirection.xlsx", index=True)
