import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import cartopy.mpl.ticker as cticker
import matplotlib as mpl
import matplotlib.pyplot as plt

# 设置全局字体为 Times New Roman，大小为 14
mpl.rcParams['font.family'] = 'Times New Roman'
# 假设数据存储在名为 'trajectory_data.txt' 的文件中
file_path = r"C:\Users\PC\Desktop\Sonde_Traj_ANQING_58424_202401281215.txt"

column_names = [
    "Time[s]", "Lon[Degree]", "Lat[Degree]", "Elev[m]",
    "U[m/s]", "V[m/s]", "W[m/s]", "P[hPa]", "T[K]", "Q[g/kg]"
]

# 读取文件并跳过前十行，指定编码为 'utf-8'
with open(file_path, 'r', encoding='utf-8') as file:
    lines = file.readlines()

# 从第十行开始读取数据
data_lines = lines[10:]

# 将数据转换为 DataFrame
trajectory_data = pd.DataFrame([line.split() for line in data_lines], columns=column_names)

# 设置数据类型
for col in ["Time[s]", "Lon[Degree]", "Lat[Degree]", "Elev[m]",
            "U[m/s]", "V[m/s]", "W[m/s]", "P[hPa]", "T[K]", "Q[g/kg]"]:
    trajectory_data[col] = pd.to_numeric(trajectory_data[col], errors='coerce')

# 删除包含缺失值的行
trajectory_data.dropna(inplace=True)

# 将压力值（hPa）转换为高度（米）
trajectory_data['Height[km]'] = ((288.15 / 0.0065) * (1 - (trajectory_data['P[hPa]'] / 1013.25) ** (1 / 5.2561)))/1000

# 绘制三维轨迹图
fig = plt.figure(figsize=(12, 8))  # 设置画布大小
ax = fig.add_subplot(111, projection='3d')

# 绘制整个轨迹
ax.plot(trajectory_data['Lon[Degree]'], trajectory_data['Lat[Degree]'], trajectory_data['Height[km]'], label='Trajectory')

# 查找对应时间点的行索引，并标记ABCD点
points_to_mark = {
    0: {'marker': '^', 'color': 'red', 'label': 'A'},       # 红色三角
    5100: {'marker': 'o', 'color': 'black', 'label': 'B'},  # 黑色圆点
    20702: {'marker': 'o', 'color': 'red', 'label': 'C'},   # 红色圆点
    25472: {'marker': '^', 'color': 'black', 'label': 'D'}  # 黑色三角
}

# 遍历每个需要标记的时间点
for time_value, style in points_to_mark.items():
    point = trajectory_data[trajectory_data["Time[s]"] == time_value]
    if not point.empty:
        # 绘制标记点
        ax.scatter(
            point['Lon[Degree]'], point['Lat[Degree]'], point['Height[km]'],
            color=style['color'], marker=style['marker'], s=100, label=f'Time = {time_value}s'
        )
        # 添加字母标注，略微偏移坐标位置以防重叠
        ax.text(
            point['Lon[Degree]'].values[0] + 0.02,  # 经度略微偏移
            point['Lat[Degree]'].values[0] + 0.02,  # 纬度略微偏移
            point['Height[km]'].values[0] + 0.02,   # 高度略微偏移
            style['label'], color=style['color'], fontsize=20, weight='bold'
        )

# 设置经纬度的刻度和格式
y_min = 30   # 纬度最小值
y_max = 32   # 纬度最大值
y_ticks = np.arange(y_min, y_max + 1, 0.2)  # 从 30 到 32，每 0.2 度一个刻度

ax.xaxis.set_major_formatter(cticker.LongitudeFormatter())
ax.yaxis.set_major_formatter(cticker.LatitudeFormatter())

# 设置轴标签和标题，并调整字体大小为14
#ax.set_xlabel('Lon', fontsize=14)
#ax.set_ylabel('Lat', fontsize=14)
ax.set_zlabel('Height (km)', fontsize=16)
#ax.set_title('Trajectory', fontsize=14)
# 在每个轴上添加边距
ax.margins(x=0.1, y=0.1, z=0.1)
# 设置 z 轴标签并调整旋转角度与偏移量
ax.set_zlabel('Height (km)', fontsize=16, rotation=0, labelpad=16)

# 设置刻度字体大小为14
ax.tick_params(axis='both', which='major', labelsize=18)  # x和y轴的刻度

# 保存为SVG格式
plt.savefig(r"C:\Users\PC\Desktop\图1 往返平飘式探空三段观测示意图.svg",bbox_inches='tight')

plt.show()
