import os
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
from matplotlib.patches import Patch, FancyArrowPatch
import matplotlib
import frykit.plot as fplt
import cartopy.mpl.ticker as cticker
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib.patches import FancyArrowPatch
import matplotlib.font_manager as fm
from matplotlib.lines import Line2D
# 设置全局字体为 Times New Roman，大小为 14
plt.rcParams['font.family'] = 'Times New Roman'
matplotlib.use('TkAgg')  # 使用Tkinter作为后端
crs = ccrs.PlateCarree()
fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(projection=crs)
fplt.add_cn_border(ax)
fplt.add_nine_line(ax)
fplt.add_cn_province(ax)

color_mapping = {
    "01": "indigo", "02": "purple", "03": "magenta",
    "04": "pink", "05": "yellow", "06": "gold",
    "07": "darkgoldenrod", "08": "red", "09": "lime",
    "10": "lightblue", "11": "royalblue", "12": "blue"
}

def extract_last_point_coordinates(file_path):
    with open(file_path, "r", encoding='utf-8') as file:
        data = file.readlines()
        try:
            station_id = data[2].split(":")[-1].strip()
            lon = float(data[4].split(":")[-1].strip())
            lat = float(data[5].split(":")[-1].strip())
            release_time = data[6].split()[-1]
            last_line = data[-1].split()
            last_lon = float(last_line[1])
            last_lat = float(last_line[2])
            return station_id, lon, lat, release_time, last_lon, last_lat
        except (ValueError, IndexError):
            return None, None, None, None, None, None

file_collections = {}
black_points = {}

root_folder_path = r"E:\\Traj_Data"
#root_folder_path = r"D:\\test"


def process_files_in_folder(folder_path):
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith(".txt"):
                file_path = os.path.join(root, file_name)
                station_id, lon, lat, release_time, last_lon, last_lat = extract_last_point_coordinates(file_path)
                release_month = release_time[4:6] if release_time else None

                if station_id and release_month in color_mapping:
                    key = (station_id, release_month)
                    if key in file_collections:
                        file_collections[key].append((last_lon, last_lat))
                    else:
                        file_collections[key] = [(last_lon, last_lat)]
                    black_points[key] = (lon, lat)

    first_release_point = True  # 用于跟踪是否已添加第一个释放点到图例

    for key, points in file_collections.items():
        total_lon = sum(lon for lon, _ in points)
        total_lat = sum(lat for _, lat in points)
        avg_lon = total_lon / len(points)
        avg_lat = total_lat / len(points)

        color_code = key[1]
        if color_code in color_mapping:
            color = color_mapping[color_code]
            ax.scatter(avg_lon, avg_lat, color=color, label=f"Month {key[1]}", s=2, transform=ccrs.PlateCarree())

            black_point_lon, black_point_lat = black_points[key]
            if first_release_point:  # 只在第一次循环时添加标签
                ax.scatter(black_point_lon, black_point_lat, color='black', label='station', marker='^', s=15,
                           transform=ccrs.PlateCarree())
                first_release_point = False  # 更新标记
            else:
                ax.scatter(black_point_lon, black_point_lat, color='black', marker='^', s=15,
                           transform=ccrs.PlateCarree())  # 之后不添加标签

            # 计算两点的距离
            distance = np.sqrt((avg_lon - black_point_lon) ** 2 + (avg_lat - black_point_lat) ** 2)

            # 根据距离动态调整缩小因子，距离越远，缩小因子越大
            if distance < 1:
                shrink_factor = 1.1  # 如果距离较近，缩小较少
            elif distance < 5:
                shrink_factor = 1.05  # 中等距离
            else:
                shrink_factor = 1.02  # 距离较远时，缩小更多

            arrow_end_lon = black_point_lon + (avg_lon - black_point_lon) * shrink_factor
            arrow_end_lat = black_point_lat + (avg_lat - black_point_lat) * shrink_factor

            # 使用尖头箭头并增加箭头大小
            arrow = FancyArrowPatch((black_point_lon, black_point_lat), (arrow_end_lon, arrow_end_lat),
                                    arrowstyle='->', mutation_scale=15, color=color)  # 调整 mutation_scale 以增加箭头大小
            ax.add_patch(arrow)


process_files_in_folder(root_folder_path)

def get_mini_ax_position(ax, geo_extent, shrink):
    """计算小地图的位置和大小"""
    transformer = ax.transData
    ll = transformer.transform([geo_extent[0], geo_extent[2]])
    ur = transformer.transform([geo_extent[1], geo_extent[3]])

    fig = ax.figure
    ll = fig.transFigure.inverted().transform(ll)
    ur = fig.transFigure.inverted().transform(ur)

    width = ur[0] - ll[0]
    height = ur[1] - ll[1]
    return [ll[0], ll[1], width * shrink, height * shrink]

def add_mini_axes(ax, extent, geo_extent, shrink=0.4, projection=None):
    """添加小地图"""
    if projection is None:
        projection = ccrs.PlateCarree()

    position = get_mini_ax_position(ax, geo_extent, shrink)

    mini_ax = ax.figure.add_axes(position, projection=projection)
    mini_ax.set_extent(extent, crs=projection)
    mini_ax.patch.set_alpha(0)  # 设置背景透明
    #for spine in mini_ax.spines.values():
        #spine.set_visible(False)  # 隐藏边框

    # 添加边界和省份
    fplt.add_cn_border(mini_ax)
    fplt.add_nine_line(mini_ax)
    fplt.add_cn_province(mini_ax)

    return mini_ax

mini_ax = add_mini_axes(ax, extent=[105, 125, 0, 25], geo_extent=[131.4, 141.4, 7.646, 22.646], shrink=0.8)#不能动

ax.set_extent([70, 140, 15, 50], crs=ccrs.PlateCarree())
#ax.set_xlabel('Lon', fontsize=14)
#ax.set_ylabel('Lat', fontsize=14)
#ax.set_title('Drop Point', fontsize=14)

legend_elements = [Patch(facecolor=color, label=f"{code}") for code, color in color_mapping.items()]

# 使用 Line2D 定义黑色圆点的图例标记
release_point_legend = Line2D([0], [0], marker='^', color='w', markerfacecolor='black', markersize=8, label='station')

# 将 release point 的 Line2D 对象添加到 legend_elements 中
legend_elements.append(release_point_legend)


# 显式为 release point 添加一个 Patch 条目
#egend_elements.append(Patch(facecolor='black', label='release point'))

# 调整图例大小并放置在左下角
ax.legend(handles=legend_elements, loc='lower left', fontsize=10)
# 设置经纬度坐标刻度
ax.set_xticks(range(70, 141, 10), crs=ccrs.PlateCarree())
ax.set_yticks(range(15, 51, 5), crs=ccrs.PlateCarree())  # 设置纬度刻度，每隔5度显示一个刻度
lon_formatter = cticker.LongitudeFormatter()
lat_formatter = cticker.LatitudeFormatter()
ax.xaxis.set_major_formatter(lon_formatter)
ax.yaxis.set_major_formatter(lat_formatter)

# 放大经纬度标记的字体
ax.tick_params(axis='both', which='major', labelsize=14)

ax.grid(False)
ax.set_facecolor("none")  # 设置背景透明
# 设置路径简化
mpl.rcParams['path.simplify'] = True
mpl.rcParams['path.simplify_threshold'] = 0.1

#plt.savefig(r'C:\Users\PC\Desktop\平均落点箭头指向1.tif', dpi=500, bbox_inches='tight')
#plt.savefig(r"C:\Users\PC\Desktop\平均落点箭头指向9.9.svg", format='svg', dpi=5, bbox_inches='tight')
plt.savefig(r"C:\Users\PC\Desktop\平均落点箭头指向10.16.png",  dpi=500, bbox_inches='tight')
plt.show()
