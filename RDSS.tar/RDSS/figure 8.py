import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'Times New Roman'
# 设置全局字体为 Times New Roman，大小为 14
mpl.rcParams['font.family'] = 'Times New Roman'
#mpl.rcParams['font.size'] = 20
# 读取Excel文件
df = pd.read_excel(r'D:\project\excel\max-min_15-25.xlsx')

# 设置月份
months = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]

plt.figure(figsize=(12, 8))

# 清理数据，将无穷大和缺失值替换为0
df.replace([np.inf, -np.inf, np.nan], 0, inplace=True)

# 绘制每个站点的最大和最小距离的折线图
for i in range(1, len(df.columns), 2):
    station_min = df.columns[i]
    station_max = df.columns[i+1]
    plt.plot(months, df[station_min], linestyle='-', marker='o', label='Min Distance' if i == 1 else "")
    plt.plot(months, df[station_max], linestyle='--', marker='x', label='Max Distance' if i == 1 else "")

# 设置x轴和y轴刻度字体大小
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)

# 设置x轴和y轴标签字体大小
plt.xlabel('Month', fontsize=16)
plt.ylabel('Distance', fontsize=16)

# 设置标题字体大小
#plt.title('Monthly Distance Range for Each Station', fontsize=16)
plt.ylim(0, 1600)
# 显示简化的图例
plt.legend(fontsize=16, loc='upper right')

plt.tight_layout()
plt.savefig(r'C:\Users\PC\Desktop\15-25 最大最小距离随月份的变化9.11.svg', bbox_inches='tight')
plt.show()
