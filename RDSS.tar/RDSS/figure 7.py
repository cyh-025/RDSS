import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
import matplotlib.cm as cm

# 设置全局字体为 Times New Roman，大小为 14
plt.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.family'] = 'Times New Roman'

# 读取 Excel 文件
#df = pd.read_excel(r"D:\project\test\arrow.xlsx")
df = pd.read_excel(r'D:\project\test\uv_speed.xlsx')
#df = pd.read_excel(r"D:\project\test\jvli.xlsx")
#df = pd.read_excel(r"D:\project\test\WindDirection.xlsx")
# 设置月份
months = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]

plt.figure(figsize=(12, 8))

# 清理数据，将无穷大和缺失值替换为 NaN
df.replace([np.inf, -np.inf], np.nan, inplace=True)

# 获取纬度的最小值和最大值
lat_min = df['Latitude'].min()
lat_max = df['Latitude'].max()

# 定义从黑到浅灰的 colormap
colormap = mpl.colors.LinearSegmentedColormap.from_list("black_gray", ["black", "lightgray"])

# 为每个站点绘制折线图
for index, row in df.iterrows():
    station_id = row['station_id']
    latitude = row['Latitude']
    y = row[months].values

    # 如果全部为缺失值，跳过此站点
    if np.all(np.isnan(y)):
        continue

    x = np.arange(len(y))

    # 根据纬度计算颜色，低纬度为浅灰，高纬度为黑色
    norm_latitude = (latitude - lat_min) / (lat_max - lat_min)
    color = colormap(norm_latitude)

    # 去除缺失值，只绘制有效数据点
    valid_mask = ~np.isnan(y)
    x_valid = x[valid_mask]
    y_valid = y[valid_mask]

    # 绘制折线图
    plt.plot(x_valid, y_valid, label=station_id, color=color)

plt.ylim(0, 40)
plt.xlim(0, len(months) - 1)
plt.xticks(np.arange(len(months)), months, fontsize=26)
plt.yticks(fontsize=26)
plt.ylabel('Speed(m\s)', fontsize=26)

# 保存图片
plt.savefig(r'C:\Users\PC\Desktop\风速10.18.svg', bbox_inches='tight')
plt.show()
