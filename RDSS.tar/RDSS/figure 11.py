import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import pandas as pd
import os
from matplotlib.colors import ListedColormap, BoundaryNorm
import cartopy.mpl.ticker as cticker
import cartopy.feature as cfeature
from cartopy.io.shapereader import Reader
from geographiclib.geodesic import Geodesic
from cartopy import geodesic
import matplotlib.font_manager as fm
import geopandas as gpd
from shapely.geometry import Point, Polygon

# 设置全局字体为 Times New Roman，大小为 14
plt.rcParams['font.family'] = 'Times New Roman'

# 文件夹路径

#folder_path = r"D:\test"
folder_path = r"E:\Traj_Data"
first_point_path = r"D:\test\2022020112"
#shapefile_path = r"D:\shp\青藏高原.shp"

# 定义网格范围和大小
lon_start, lon_end, lon_step = 70, 140, 1.4
lat_start, lat_end, lat_step = 15, 55, 1.4

# 创建网格数组
lon_bins = np.arange(lon_start, lon_end + lon_step, lon_step)
lat_bins = np.arange(lat_start, lat_end + lat_step, lat_step)

# 初始化计数数组
count_array = np.zeros((len(lat_bins) - 1, len(lon_bins) - 1), dtype=int)

# 获取第一个点的经纬度
first_file = os.listdir(first_point_path)[0]
first_file_path = os.path.join(first_point_path, first_file)
first_line = pd.read_csv(first_file_path, sep='\s+', skiprows=10, nrows=1)
first_lon, first_lat = float(first_line.iloc[0, 1]), float(first_line.iloc[0, 2])

# 使用os.walk()遍历文件夹及其所有子文件夹中的文件
for root, dirs, files in os.walk(folder_path):
    for filename in files:
        if filename.endswith('.txt'):
            file_path = os.path.join(root, filename)
            try:
                # 读取数据，跳过头部信息
                data = pd.read_csv(file_path, sep='\s+', skiprows=14)
                # 提取最后一行的经纬度
                last_point = data.iloc[-1]
                lon, lat = last_point.iloc[1], last_point.iloc[2]

                # 忽略无效的数据点
                if not np.isfinite(lon) or not np.isfinite(lat):
                    continue

                # 计算落在哪个网格内并累加次数
                lon_idx = np.digitize(lon, lon_bins) - 1
                lat_idx = np.digitize(lat, lat_bins) - 1
                if 0 <= lon_idx < len(lon_bins) - 1 and 0 <= lat_idx < len(lat_bins) - 1:
                    count_array[lat_idx, lon_idx] += 1
            except Exception as e:
                print(f"处理文件 {filename} 时出错: {e}")

# 根据频数设置颜色索引
color_array = np.zeros_like(count_array)
color_array[(count_array > 0) & (count_array <= 200)] = 1  # 蓝色
color_array[(count_array > 200) & (count_array <= 400)] = 2  # 绿色
color_array[(count_array > 400) & (count_array <= 600)] = 3  # 黄色
color_array[count_array > 600] = 4  # 红色

# 创建绘图
fig, ax = plt.subplots(figsize=(12, 8), subplot_kw={'projection': ccrs.PlateCarree()})
# 添加海陆边界特征
ax.add_feature(cfeature.LAND)
ax.add_feature(cfeature.OCEAN)
ax.add_feature(cfeature.COASTLINE, linewidth=0.5)
# 定义颜色映射
cmap = ListedColormap(['white', 'blue', 'green', 'yellow', 'red'])
bounds = [0, 1, 2, 3, 4, 5]
norm = BoundaryNorm(bounds, cmap.N)

# 使用pcolormesh绘制地图
mesh = ax.pcolormesh(lon_bins, lat_bins, color_array, cmap=cmap, norm=norm, edgecolors='k', linewidth=0.5, transform=ccrs.PlateCarree())

# 添加shapefile
#shape_feature = cfeature.ShapelyFeature(Reader(shapefile_path).geometries(), ccrs.PlateCarree(), edgecolor='black', facecolor='none')
#ax.add_feature(shape_feature)

# 定义计算圆周点的函数
def calculate_circle_points(lon, lat, radius_km, num_points=360):
    geod = Geodesic.WGS84
    circle_lons = []
    circle_lats = []
    for angle in np.linspace(0, 360, num_points):
        g = geod.Direct(lat, lon, angle, radius_km * 1000)
        circle_lons.append(g['lon2'])
        circle_lats.append(g['lat2'])
    return circle_lons, circle_lats

# 绘制150公里范围内的区域（进行白色填色）
for file_name in os.listdir(first_point_path):
    if file_name.endswith(".txt"):
        file_path = os.path.join(first_point_path, file_name)
        with open(file_path, "r") as file:
            data = file.readlines()
        first_line = data[10].split()
        lon_given = float(first_line[1])
        lat_given = float(first_line[2])
        if lon_given is not None and lat_given is not None:
            # 计算150公里范围内的点
            lons, lats = calculate_circle_points(lon_given, lat_given, 75)
            # 绘制白色填充区域
            ax.fill(lons, lats, color='white', transform=ccrs.PlateCarree())

# 绘制第一个点
for file_name in os.listdir(first_point_path):
    if file_name.endswith(".txt"):
        file_path = os.path.join(first_point_path, file_name)
        with open(file_path, "r") as file:
            data = file.readlines()
        first_line = data[10].split()
        lon_given = float(first_line[1])
        lat_given = float(first_line[2])
        if lon_given is not None and lat_given is not None:
            ax.scatter(lon_given, lat_given, color='black', marker='o', s=10, transform=ccrs.PlateCarree(), label='release point')
            # 绘制150km范围内的圆
            circle = geodesic.Geodesic().circle(lon_given, lat_given, 75000)  # 半径150km
            ax.plot(circle[:, 0], circle[:, 1], transform=ccrs.PlateCarree(), color='black', linewidth=1)

# 设置经纬度格式和刻度
lon_formatter = cticker.LongitudeFormatter()
lat_formatter = cticker.LatitudeFormatter()
ax.xaxis.set_major_formatter(lon_formatter)
ax.yaxis.set_major_formatter(lat_formatter)
ax.set_xticks(np.arange(lon_start, lon_end + 10, 10), crs=ccrs.PlateCarree())
ax.set_yticks(np.arange(lat_start, lat_end + 10, 10), crs=ccrs.PlateCarree())
ax.tick_params(axis='both', which='major', labelsize=14)
#plt.xlabel('Lon', fontsize=14)
#plt.ylabel('Lat', fontsize=14)
#ax.set_title('Grade coloring diagram', fontsize=14)
ax.set_aspect('equal', adjustable='box')

fig.subplots_adjust(bottom=0.2)
cbar_ax = fig.add_axes([0.15, 0.1, 0.7, 0.03])

# 色标
cbar = fig.colorbar(mesh, cax=cbar_ax, orientation='horizontal')
cbar.ax.tick_params(axis='x', which='both', length=0)  # 移除刻度线
cbar.ax.tick_params(labelsize=14)

# 刻度位置
cbar.set_ticks([0.5, 1.5, 2.5, 3.5, 4.5])
cbar.set_ticklabels(['0', '1', '2', '3', '4'])

cbar.ax.xaxis.set_tick_params(size=0)  # 没有小刻度线

# 保存并显示图像
plt.savefig(r'C:\Users\PC\Desktop\1.4(换频数).svg', dpi=5, bbox_inches='tight')
plt.show()

# ------------------- 添加空间查询功能 -------------------

# 选择所需国家
selected_countries = ['CHINA']  # 确保shapefile中的国家名称为'China'

shp_path = r'D:\worldmap\worldmap.shp'  # 世界地图shapefile路径
world_shp = gpd.read_file(shp_path, encoding='utf-8')  # 根据shapefile的编码进行调整
world_shp = world_shp[world_shp['NAME'].isin(selected_countries)].to_crs(epsg=4326)

# 创建网格单元的几何图形
polygons = []
for lat_idx in range(len(lat_bins)-1):
    for lon_idx in range(len(lon_bins)-1):
        if count_array[lat_idx, lon_idx] > 0:
            # 定义每个网格的四个角点
            lon_min = lon_bins[lon_idx]
            lon_max = lon_bins[lon_idx + 1]
            lat_min = lat_bins[lat_idx]
            lat_max = lat_bins[lat_idx + 1]
            polygon = Polygon([
                (lon_min, lat_min),
                (lon_min, lat_max),
                (lon_max, lat_max),
                (lon_max, lat_min)
            ])
            polygons.append({
                'geometry': polygon,
                'count': count_array[lat_idx, lon_idx],
                'color_idx': color_array[lat_idx, lon_idx]
            })

# 创建GeoDataFrame
grid_gdf = gpd.GeoDataFrame(polygons, crs='EPSG:4326')

# 空间连接，判断哪些网格在中国区域内
grid_in_china = gpd.sjoin(grid_gdf, world_shp, how='inner', predicate='intersects')

# 统计有频数的网格总数量
total_grids_with_counts = len(grid_gdf)

# 统计中国区域内有频数的网格总数量
grids_in_china = len(grid_in_china)

# 统计不同颜色网格的总数量
blue_grids = len(grid_gdf[grid_gdf['color_idx'] == 1])
green_grids = len(grid_gdf[grid_gdf['color_idx'] == 2])
yellow_grids = len(grid_gdf[grid_gdf['color_idx'] == 3])
red_grids = len(grid_gdf[grid_gdf['color_idx'] == 4])

# 输出统计结果
print("统计结果如下：")
print(f"1. 有频数的网格总数量: {total_grids_with_counts} 个")
print(f"2. 中国区域内有频数的网格总数量: {grids_in_china} 个")
print(f"3. 蓝色网格的总数量: {blue_grids} 个")
print(f"4. 绿色网格的总数量: {green_grids} 个")
print(f"5. 黄色网格的总数量: {yellow_grids} 个")
print(f"6. 红色网格的总数量: {red_grids} 个")


# ------------------- 添加输出每个网格中频数的代码 -------------------

# 创建包含网格边界和频数的DataFrame
grid_counts = grid_gdf.copy()
grid_counts['lon_min'] = grid_counts['geometry'].bounds.minx
grid_counts['lon_max'] = grid_counts['geometry'].bounds.maxx
grid_counts['lat_min'] = grid_counts['geometry'].bounds.miny
grid_counts['lat_max'] = grid_counts['geometry'].bounds.maxy
grid_counts = grid_counts[['lon_min', 'lon_max', 'lat_min', 'lat_max', 'count']]

# 将网格频数保存为CSV文件
output_csv_path = r'C:\Users\PC\Desktop\grid_counts1.4频数不同.csv'
grid_counts.to_csv(output_csv_path, index=False, encoding='utf-8-sig')

print(f"每个网格的频数已保存至 {output_csv_path}")

