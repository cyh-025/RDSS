import matplotlib.pyplot as plt
import pandas as pd
import cartopy.crs as ccrs
import frykit.plot as fplt
import cartopy.mpl.ticker as cticker
import matplotlib as mpl
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'Times New Roman'
# 设置全局字体为 Times New Roman，大小为 14
mpl.rcParams['font.family'] = 'Times New Roman'
def get_mini_ax_position(ax, geo_extent, shrink):
    """Calculate position and size of the mini-axes based on geographical location"""
    transformer = ax.transData
    ll = transformer.transform([geo_extent[0], geo_extent[2]])  # Lower left corner
    ur = transformer.transform([geo_extent[1], geo_extent[3]])  # Upper right corner

    fig = ax.figure
    ll = fig.transFigure.inverted().transform(ll)
    ur = fig.transFigure.inverted().transform(ur)

    width = ur[0] - ll[0]
    height = ur[1] - ll[1]
    return [ll[0], ll[1], width * shrink, height * shrink]

def add_mini_axes(ax, extent, geo_extent, shrink=0.4, projection=None):
    """Add a mini-map axes showing a specific geographic area"""
    if projection is None:
        projection = ccrs.PlateCarree()  # Default projection

    position = get_mini_ax_position(ax, geo_extent, shrink)


    mini_ax = ax.figure.add_axes(position, projection=projection)
    mini_ax.set_extent(extent, crs=projection)
    mini_ax.patch.set_alpha(0)  # 设置背景透明
    # Optional: add borders or other geographic features
    fplt.add_cn_border(mini_ax)
    fplt.add_nine_line(mini_ax)
    fplt.add_cn_province(mini_ax)
    return mini_ax

# 读取数据
df = pd.read_excel(r"D:\project\excel\station_coordinates.xlsx")

# Initialize the map
crs = ccrs.PlateCarree()
fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(projection=crs)

# Add features to the map
fplt.add_cn_border(ax)
fplt.add_nine_line(ax)
fplt.add_cn_province(ax)

# Iterate through the DataFrame to plot each point and add text labels for points
for index, row in df.iterrows():
    ax.plot(row['Longitude'], row['Latitude'], 'ko', markersize=5, transform=crs)  # Black dots ('ko') for the stations
    # Adding a text label for the points column, with an arrow
    plt.annotate(f"{row['ruhai']}", xy=(row['Longitude'], row['Latitude']), xytext=(3, 3), textcoords='offset points',
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3"), transform=crs)

# 添加南海小地图
mini_ax = add_mini_axes(ax, extent=[105, 125, 0, 25], geo_extent=[130.1, 140.1, 2.9, 22.9], shrink=0.8)

# 设置经纬度格式和刻度
lon_formatter = cticker.LongitudeFormatter()
lat_formatter = cticker.LatitudeFormatter()
ax.xaxis.set_major_formatter(lon_formatter)
ax.yaxis.set_major_formatter(lat_formatter)

ax.set_extent([70, 140, 15, 55], crs=ccrs.PlateCarree())
ax.set_xticks(range(70, 141, 10))
ax.set_yticks(range(15, 56, 10))
ax.tick_params(axis='both', which='major', labelsize=14)
ax.grid(False)
ax.set_facecolor("none")  # 设置背景透明
plt.savefig(r'C:\Users\PC\Desktop\入海.svg', bbox_inches='tight')
plt.show()
