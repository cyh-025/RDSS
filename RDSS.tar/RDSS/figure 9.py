import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.gridspec as gridspec
import numpy as np
import matplotlib as mpl

plt.rcParams['font.family'] = 'Times New Roman'

# 读取Excel文件
file_path = r"D:\project\average\每月落入其他国家次数.xlsx"
df = pd.read_excel(file_path, index_col=0)

# 确保数据类型是整型
df = df.astype(int)

# 分离最后一列以使用不同的色板
df_main = df.iloc[:, :-1]  # 除最后一列之外的所有数据
df_last_column = df.iloc[:, -1:]  # 最后一列数据

# 定义一个自定义的颜色映射，其中最后一列使用不同的颜色
cmap_main = sns.color_palette("viridis", as_cmap=True)
cmap_last = sns.color_palette("plasma", as_cmap=True)

# 将df_main和df_last_column合并，但df_last_column单独使用另一种颜色
df_combined = pd.concat([df_main, df_last_column], axis=1)

# 生成一个新数组，区分主图数据和最后一列数据
mask = np.zeros(df_combined.shape)
mask[:, -1] = 1  # 将最后一列标记为1

# 初始化绘图，调整figure的高度以增加y轴每格的长度
plt.figure(figsize=(16, len(df_combined) * 0.38))
gs = gridspec.GridSpec(1, 1)

# 定义色标参数
cbar_kws_main = {"shrink": 0.8, "aspect": 10, "fraction": 0.046, "pad": 0.04}

# 绘制整个数据集的热图，但使用mask区分不同的色图
ax = plt.subplot(gs[0])

# 在主图部分应用viridis色图，并设置注释字体大小
sns.heatmap(df_combined, annot=True, fmt="d", cmap=cmap_main, linewidths=.5, ax=ax,
            cbar_kws=cbar_kws_main, mask=mask, annot_kws={"size": 20})

# 在最后一列应用plasma色图，但不绘制新的色标，且设置相同的注释字体大小
sns.heatmap(df_combined, annot=True, fmt="d", cmap=cmap_last, linewidths=.5, ax=ax,
            mask=1-mask, cbar=False, annot_kws={"size": 20})

# 设置标题和标签
ax.set_ylabel('Station', fontsize=30)
ax.set_xlabel('Month', fontsize=30)

# 设置x轴和y轴标签字体大小
ax.set_xticklabels(df_combined.columns, rotation=0, ha='center', fontsize=25)
ax.set_yticklabels(df_combined.index, rotation=0, fontsize=20)

# 获取colorbar并设置字体大小
cbar = ax.collections[0].colorbar
cbar.ax.tick_params(labelsize=24)  # 设置colorbar刻度的字体大小

# 调整整个图表的布局
plt.tight_layout(pad=3.0)
plt.savefig(r"C:\Users\PC\Desktop\热图-名称.svg", format='svg', bbox_inches='tight')
plt.show()

